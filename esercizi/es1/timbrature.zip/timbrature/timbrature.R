###########################################################################################
#    Trasformazione del file lungo in largo con la funzione reshape()                     #
#    (package R :stats - presente di default nell'istallazione di R                       #
#    Utile per l'aggiunta nel db timbrature della tabella "larga"                         #                                                                 #
###########################################################################################

setwd("~/workspace/timbrature")
rm(list=ls(all=TRUE))


# Funzione che aggiunge la colonna "ORD" che completa la chiave 
metti.ord<-function(DF)
  {
	ORD<-NULL
	num.direz.timbr<-table(DF$dip,DF$verso)
	L<-nrow(num.direz.timbr)
	for(ind in 1:L)
		{
		if(num.direz.timbr[ind,1]>0) {ord.entrate.ind<-1:(num.direz.timbr[ind,1])}
		else				     {ord.entrate.ind<-NULL}

		if(num.direz.timbr[ind,2]>0) {ord.uscite.ind<- 1:(num.direz.timbr[ind,2])}
		else 				     {ord.uscite.ind<-NULL}
		
		ord.ind<-sort(c(ord.entrate.ind, ord.uscite.ind))
		ORD<-c(ORD, ord.ind)
		}
	cbind(DF,ORD)
	}


##########################################################################################
##   (Applicazione alle timbrature  effettive (prova col .csv della DG OR di ottobre)   ##
##########################################################################################
# Lettura di una DG

library(RJDBC)
drv <- JDBC(driverClass="com.ibm.db2.jcc.DB2Driver", classPath="C:/Programmi/SQuirreL SQL Client/lib/db2/db2jcc.jar", identifier.quote=NA)
conn<- dbConnect(drv,"jdbc:db2://db2dwp1.regione.toscana.it:50000/OSI:currentSchema=DMPERSECO;","dmpersrw","C842477i")

# LETTURA DEL CSV DELLE TIMBRATURE DI DICEMBRE: DG ORGANIZZAZIONE


#setwd("C:\\Documents and Settings\\UserRegTosc\\Documenti\\DSS\\ANALISI PERSONALE\\Compresenza")
#ORG<-read.csv2("dg_organizzazione_dicembre.csv", header = TRUE, sep = ";",
#               as.is=TRUE, quote="\"", dec=",")


ORG<-dbGetQuery(conn,"
  SELECT
    DMPERSECO.TIMBRATURE.TB_DATA_TIMB as DATA,
    DMPERSECO.TIMBRATURE.MATRICOLA,
    DMPERSECO.TIMBRATURE.ORA,
    DMPERSECO.TIMBRATURE.TB_SIGLA_TIPO_VERSO_TIMB as VERSO,
    CASE WHEN DMPERSECO.TIMBRATURE.TB_FLAG='O' THEN 'Timbratura Originale'
         WHEN DMPERSECO.TIMBRATURE.TB_FLAG='I' THEN 'Timbratura Inserita'
         WHEN DMPERSECO.TIMBRATURE.TB_FLAG='M' THEN 'Timbratura Modificata'
         ELSE 'Altro'
    END AS TIPO
  FROM DMPERSECO.TIMBRATURE
      LEFT OUTER JOIN DMPERSECO.V_INQUADRAMENTO_DIP DMPERSECO_V_INQUADRAMENTO_DIP_MANSIONE
                ON DMPERSECO.TIMBRATURE.MATRICOLA=DMPERSECO_V_INQUADRAMENTO_DIP_MANSIONE.MATRICOLA
                AND DMPERSECO.TIMBRATURE.DATA>=DMPERSECO_V_INQUADRAMENTO_DIP_MANSIONE.II_DT_ENABLE
                AND DMPERSECO.TIMBRATURE.DATA<=COALESCE(DMPERSECO_V_INQUADRAMENTO_DIP_MANSIONE.II_DT_DISABLE ,30000101)
                AND TRIM(DMPERSECO_V_INQUADRAMENTO_DIP_MANSIONE.IG_RICL)='DISCIPLINE',
    DMPERSECO.D_DG,
    DMPERSECO.D_SETTORE,
    DMPERSECO.UP1ADR00_MANSIONE,
    DMPERSECO.D_GERARCHIA,
  (
    SELECT C.MATRICOLA,C.TB_DATA_TIMB,C.DATA,C.CMU_UO,C.CMU_UF,C.CMU_INC,C.CMU,
      CASE
        WHEN D.ID_GERARCHIA IS NOT NULL THEN D.ID_GERARCHIA
        WHEN F.ID_GERARCHIA IS NOT NULL THEN F.ID_GERARCHIA
        WHEN H.ID_GERARCHIA IS NOT NULL THEN H.ID_GERARCHIA
      END ID_GERARCHIA
    FROM
      (
        select
  A.MATRICOLA,A.TB_DATA_TIMB,A.DATA,A.CMU_UO,A.CMU_UF,A.CMU_INC,A.CMU,
        B.ID_SETTORE, E.ID_AREA, G.ID_DG
        FROM DMPERSECO.V_ASSEGN_GERARCHIE_TIMBRATURE_APPO A
          LEFT OUTER JOIN DMPERSECO.D_SETTORE B ON A.CMU=B.CMU
          LEFT OUTER JOIN DMPERSECO.D_AREA E ON A.CMU=E.CMU
          LEFT OUTER JOIN DMPERSECO.D_DG G ON A.CMU=G.CMU
      ) C
    LEFT OUTER JOIN DMPERSECO.D_GERARCHIA D ON C.ID_SETTORE=D.ID_SETTORE  AND D.ID_PO=1 and c.data between d.div and d.dfv
    LEFT OUTER JOIN DMPERSECO.D_GERARCHIA F ON C.ID_AREA=F.ID_AREA  AND F.ID_PO=1 AND F.ID_SETTORE=1 and c.data between f.div and f.dfv
    LEFT OUTER JOIN DMPERSECO.D_GERARCHIA H ON C.ID_DG=H.ID_DG  AND H.ID_PO=1 AND H.ID_SETTORE=1 AND H.ID_AREA=1 and c.data between h.div and h.dfv
  ) AS V_ASSEGN_GERARCHIE_TIMBRATURE
  WHERE
  ( DMPERSECO.TIMBRATURE.MATRICOLA=V_ASSEGN_GERARCHIE_TIMBRATURE.MATRICOLA
      AND
  DMPERSECO.TIMBRATURE.TB_DATA_TIMB=V_ASSEGN_GERARCHIE_TIMBRATURE.TB_DATA_TIMB  )
    AND  ( V_ASSEGN_GERARCHIE_TIMBRATURE.ID_GERARCHIA=DMPERSECO.D_GERARCHIA.ID_GERARCHIA  )
    AND  ( DMPERSECO.D_GERARCHIA.ID_SETTORE=DMPERSECO.D_SETTORE.ID_SETTORE )
    AND  ( DMPERSECO.D_GERARCHIA.ID_DG=DMPERSECO.D_DG.ID_DG  )
    AND  ( DMPERSECO_V_INQUADRAMENTO_DIP_MANSIONE.IG_CODICE=DMPERSECO.UP1ADR00_MANSIONE.DR_CDCC  )
    AND 
    (
     TRIM(DMPERSECO.D_DG.NOME)  IN  ( 'ORGANIZZAZIONE'  )
   AND
   DMPERSECO.UP1ADR00_MANSIONE.DR_CDCC  NOT IN
      ( 'B01M11  ','B03M11  ','B3CI01  ','B93500  ','C92500  ','CC1M11  ','DD1M11  ','E93500  ' )
  )");


ORG$Cmu.DG<-NULL
ORG$Nome.DG<-NULL
ORG$Cmu.Settore<-NULL
ORG$Nome.Settore<-NULL
ORG$Descrizione.flag.timbratura<-NULL


# Trasformazioni e rinomine di variabili
ORG$dip<-paste(substr(ORG$DATA,1, 10), ORG$MATRICOLA,  sep=".")
ORG$verso<-substr(ORG$VERSO,1,1)
ORG$ora<-60*as.numeric(substr(ORG$ORA, 1, 2)) + 
                  as.numeric(substr(ORG$ORA, 4, 5))

# Eliminazione delle variabili usate per le trasformazioni e rinomine
ORG$DATA<-NULL
ORG$MATRICOLA<-NULL
ORG$ORA<-NULL
ORG$VERSO<-NULL


ORG<-ORG[order(ORG$dip, ORG$ora),]  	# Ordinamento per dip e verso
# ORG[1:40,]					# Visualizzazione dei primi 40 record


ORG2<-metti.ord(ORG)				# Aggiunta della variabile ORD con la funzione ad hoc
# ORG2[1:40,]					# Visualizzazione dei primi 40 record

# Tabella delle entrate/uscite X numero
# addmargins(table(ORG2$verso, ORG2$ORD))


# Applicazione della reshape (� molto veloce!!)
ORG3<-reshape(ORG2, idvar=c("dip", "ORD"), timevar=c("verso"), direction="wide",sep="_")
ORG3<-reshape(ORG3, idvar=c("dip"), timevar=c("ORD"), direction="wide",,sep="_")

# Riseparazione della Data dalla Matricola ed eliminazione della variabile "dip"
ORG3$Data<-substr(ORG3$dip,1,10)
ORG3$Matricola<-as.numeric(substr(ORG3$dip, 12,16))
ORG3$dip<-NULL

# str(ORG3)
# ORG3[1:40,]		# Visualizzazione dei primi 40 record della tabella da inserire nel DB


dbSendUpdate(conn,"DROP table DMPERSECO.ORG3");
dbWriteTable(conn,"DMPERSECO.ORG3",ORG3,append=F,row.name=F);


##############################################################################################