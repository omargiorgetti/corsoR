###########################################################################################
#    Trasformazione del file lungo in largo con la funzione reshape()                     #
#    (package R :stats - presente di default nell'istallazione di R                       #
#    Utile per l'aggiunta nel db timbrature della tabella "larga"                         #                                                                 #
###########################################################################################

################################## File lungo di prova ###################################
orari<-data.frame(dip=rep(1:8, times=c(6, 4, 4, 2,4,1,1,3)),
                  verso=c(rep(c("E", "U"), 10),"E","U","E", "U", "E"),
                  ora=c(450,800,831,910,975,1078,470,810,844,995,490,842,880,
                        960,500,830,560,840,872,1070, 540, 830, 455, 770,990))
                  
orari

# Funzione che aggiunge la colonna "ORD" che completa la chiave 
metti.ord<-function(DF)
	{
	ORD<-NULL
	num.direz.timbr<-table(DF$dip,DF$verso)
	L<-nrow(num.direz.timbr)
	for(ind in 1:L)
		{
		if(num.direz.timbr[ind,1]>0) {ord.entrate.ind<-1:(num.direz.timbr[ind,1])}
		else				     {ord.entrate.ind<-NULL}

		if(num.direz.timbr[ind,2]>0) {ord.uscite.ind<- 1:(num.direz.timbr[ind,2])}
		else 				     {ord.uscite.ind<-NULL}
		
		ord.ind<-sort(c(ord.entrate.ind, ord.uscite.ind))
		ORD<-c(ORD, ord.ind)
		}
	cbind(DF,ORD)
	}

orari2<-metti.ord(orari)
orari2

# Costruzione del file "largo" con due passaggi!!!!
orari2<-reshape(orari2, idvar=c("dip", "ORD"), timevar=c("verso"), direction="wide")
orari3<-reshape(orari2, idvar=c("dip"), timevar=c("ORD"), direction="wide")
orari3

# Si gesticono casi con una sola entrata, casi con una sola uscita, 
# casi con timbrature dispari che possono verificarsi per i dirigenti

	
##########################################################################################
##   (Applicazione alle timbrature  effettive (prova col .csv della DG OR di ottobre)   ##
##########################################################################################

# Lettura di una DG
setwd("C:\\Documents and Settings\\UserRegTosc\\Documenti\\DSS\\ANALISI PERSONALE\\Compresenza")
ORG<-read.csv2("dg_organizzazione_ottobre.csv", header = TRUE, sep = ";",  
               as.is=TRUE, quote="\"", dec=",")
# str(ORG)

# Eliminazione delle varibili superflue (si potrebbe non leggerle con la query)
ORG$Cmu.DG<-NULL
ORG$Nome.DG<-NULL
ORG$Cmu.Settore<-NULL
ORG$Nome.Settore<-NULL
ORG$Descrizione.flag.timbratura<-NULL


# Trasformazioni e rinomine di variabili
ORG$dip<-paste(substr(ORG$Data,1, 10), ORG$Matricola,  sep=".")
ORG$verso<-substr(ORG$Verso.timbratura,1,1)
ORG$ora<-60*as.numeric(substr(ORG$Ora.timbratura, 1, 2)) + 
                  as.numeric(substr(ORG$Ora.timbratura, 4, 5))

# Eliminazione delle variabili usate per le trasformazioni e rinomine
ORG$Data<-NULL
ORG$Matricola<-NULL
ORG$Ora.timbratura<-NULL
ORG$Verso.timbratura<-NULL


ORG<-ORG[order(ORG$dip, ORG$ora),]		# Ordinamento per dip e verso
# ORG[1:40,]					# Visualizzazione dei primi 40 record


ORG2<-metti.ord(ORG)				# Aggiunta della variabile ORD con la funzione ad hoc
# ORG2[1:40,]					# Visualizzazione dei primi 40 record

# Tabella delle entrate/uscite X numero
# addmargins(table(ORG2$verso, ORG2$ORD))


# Applicazione della reshape (� molto veloce!!)
ORG3<-reshape(ORG2, idvar=c("dip", "ORD"), timevar=c("verso"), direction="wide")
ORG3<-reshape(ORG3, idvar=c("dip"), timevar=c("ORD"), direction="wide")

# Riseparazione della Data dalla Matricola ed eliminazione della variabile "dip"
ORG3$Data<-substr(ORG3$dip,1,10)
ORG3$Matricola<-as.numeric(substr(ORG3$dip, 12,16))
ORG3$dip<-NULL

# str(ORG3)
# ORG3[1:40,]		# Visualizzazione dei primi 40 record della tabella da inserire nel DB



##############################################################################################